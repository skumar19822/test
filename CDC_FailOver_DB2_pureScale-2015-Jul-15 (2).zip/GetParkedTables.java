
/****************************************************************************
** Licensed Materials - Property of IBM 
** IBM InfoSphere Change Data Capture
** 5724-U70
** 
** (c) Copyright IBM Corp. 2011 All rights reserved.
** 
** The following sample of source code ("Sample") is owned by International 
** Business Machines Corporation or one of its subsidiaries ("IBM") and is 
** copyrighted and licensed, not sold. You may use, copy, modify, and 
** distribute the Sample in any form without payment to IBM.
** 
** The Sample code is provided to you on an "AS IS" basis, without warranty of 
** any kind. IBM HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
** IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Some jurisdictions do 
** not allow for the exclusion or limitation of implied warranties, so the above 
** limitations or exclusions may not apply to you. IBM shall not be liable for 
** any damages you suffer as a result of using, copying, modifying or 
** distributing the Sample, even if IBM has been advised of the possibility of 
** such damages.
*****************************************************************************/

/**
 * This sample shows how to automate checking the status for table mappings, 
 * specifically in this case reporting any parked tables to stdout. 
 * 
 * All subscriptions in all agents are checked. If an agent is not available 
 * (i.e. not running) then it's reported and skipped.
 *
 *
 * The sample can be easily modified to report additional statuses and 
 * information as desired.
 *
 */


package api.sample;

import com.datamirror.ea.api.ApiException;
import com.datamirror.ea.api.DBPath;
import com.datamirror.ea.api.DataSource;
import com.datamirror.ea.api.DefaultContext;
import com.datamirror.ea.api.Toolkit;
import com.datamirror.ea.api.publisher.Publisher;
import com.datamirror.ea.api.publisher.SubscribedTable;
import com.datamirror.ea.api.publisher.Subscription;


public class GetParkedTables {
	
	//Access Server credentials
	private static final String USER = "accessServerUser";
	private static final String PASSWORD = "password";
	private static final String HOST = "acessServerHost";
	private static final int PORT = 10101;
	
    private static DataSource accessServer;
    
	
	public static void main(String[] args) {
	
		DefaultContext c = new DefaultContext();
		c.setString(DataSource.User, USER);
		c.setString(DataSource.Password, PASSWORD);
		c.setString(DataSource.Hostname, HOST);
		c.setInt(DataSource.Port, PORT);
	    
	    try {
			accessServer = Toolkit.getDefaultToolkit().createDataSource();
			accessServer.connect(c);
		} catch (ApiException e) {
			e.printStackTrace();
		}
		
		
		System.out.println("Start");
		getSubscriptionInfo(accessServer);
	   
		System.out.println("All done");

   }
	
	/*
	 *Examine subscriptions for parked table mappings and output results to stdout
     */
	
    private static void getSubscriptionInfo(DataSource accessServer) {
	   
    	String replicationMethod = "Refresh";
    	String replicationStatus = "Active";
    	
	    System.out.println("Get parked table mappings for all subscriptions for all agents...");
	    
        try {
			
			if (accessServer != null && accessServer.isOpen()) {
				Publisher[] publishers = accessServer.getPublishers();
				for (Publisher publisher : publishers) {
					System.out.println("Agent: " + publisher.getName());
					if (!publisher.isConnected()) {
						
						try {
							publisher.connect();
						} catch (ApiException e) {
							System.out.println("Unable to connect to agent " + publisher.getName() + " - may not be running, skipping it");
							continue;
				        }
					} 
					String[] subnames = publisher.getSubscriptionNames();
					for (String sub : subnames) {
						Subscription subscription = publisher.getSubscription(sub);
						DBPath[] paths = subscription.getSubscribedTableDBPaths();
						for (DBPath path : paths) {
							SubscribedTable[] subscribedtables = subscription.getSubscribedTables(path);
							for (SubscribedTable table : subscribedtables) {
								String name = table.getName();
								if (SubscribedTable.METHOD_MIRROR == table.getReplicationMethod()) {
									replicationMethod = "Mirror";
								}
								else {
									replicationMethod = "Refresh";
								}
								if (SubscribedTable.STATUS_IDLE == table.getReplicationStatus()) {
									replicationStatus = "Parked";
									System.out.println("Subscription:" + sub + "\t Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else {
									continue;
								}
							}//for each subscribed table in sub:path
						}//for each path in subscription 
					}//for each subscription in publisher
					if (publisher != null && publisher.isConnected()) {
					    publisher.disconnect();
					}
				}//for each publisher
			}//if
		} catch (ApiException e) {
			e.printStackTrace();
		}
   }
}

