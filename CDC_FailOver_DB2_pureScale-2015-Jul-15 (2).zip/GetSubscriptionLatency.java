/****************************************************************************
** Licensed Materials - Property of IBM
** IBM InfoSphere Change Data Capture
** 5724-U70
**
** (c) Copyright IBM Corp. 2011 All rights reserved.
**
** The following sample of source code ("Sample") is owned by International
** Business Machines Corporation or one of its subsidiaries ("IBM") and is
** copyrighted and licensed, not sold. You may use, copy, modify, and
** distribute the Sample in any form without payment to IBM.
**
** The Sample code is provided to you on an "AS IS" basis, without warranty of
** any kind. IBM HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR
** IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Some jurisdictions do
** not allow for the exclusion or limitation of implied warranties, so the above
** limitations or exclusions may not apply to you. IBM shall not be liable for
** any damages you suffer as a result of using, copying, modifying or
** distributing the Sample, even if IBM has been advised of the possibility of
** such damages.
*****************************************************************************/

/**
 * This sample shows how to use the API to get status for all subscriptions
 * in all running agents, and output to stdout values for the following:
 * PUBDESC,SUBDESC,SUBSCRIPTION,PUBID,SRCTBL,TGTTBL,LATENCY
 *
 * It requires Management Console 6.5.2 IF3 or later to compile and run as
 * the monitoring API methods changed with that release.
 *
 * If a subscription is idle (ie not mirroring) then the latency value is just
 * 'not active'.
 *
 */


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import com.datamirror.ea.api.ApiException;
import com.datamirror.ea.api.Context;
import com.datamirror.ea.api.DBPath;
import com.datamirror.ea.api.DBTable;
import com.datamirror.ea.api.DataSource;
import com.datamirror.ea.api.DefaultContext;
import com.datamirror.ea.api.SummaryStatisticData;
import com.datamirror.ea.api.Toolkit;
import com.datamirror.ea.api.publisher.Publisher;
import com.datamirror.ea.api.publisher.SubscribedTable;
import com.datamirror.ea.api.publisher.Subscription;
import com.datamirror.ea.api.subscriber.Publication;
import com.datamirror.ea.api.subscriber.PublishedTable;
import com.datamirror.ea.api.subscriber.Subscriber;
import com.datamirror.ea.api.subscriber.TableAssignment;


public class GetSubscriptionLatency {

	//Access Server credentials
	private static String user 	= "Admin";
	private static String password = "Happy123";
	private static String host = "abeatonw520";
	private static String port = "10101";
	private static int portnumber = 10101;

    private static DataSource accessServer;
    private static final String NEWLINE = System.getProperty("line.separator");

    private static String configfile="";

	public static void main(String[] args) {

        //only valid arg is location of user defined properties file
        if  (args.length==0) {
            System.out.println("No arguments were supplied.");
            System.out.println("Provide the name and location of AccessServer.cfg as an argument");
            System.exit(0);
        }

        configfile = args[0];

        readConfigFile(configfile);

        System.out.println("Connecting to AccessServer at " + host + " on port:" + port + " as UserID " + user);

		DefaultContext c = new DefaultContext();
		c.setString(DataSource.User, user);
		c.setString(DataSource.Password, password);
		c.setString(DataSource.Hostname, host);
		c.setInt(DataSource.Port, portnumber);

	    try {
			accessServer = Toolkit.getDefaultToolkit().createDataSource();
			accessServer.connect(c);
		} catch (ApiException e) {
			e.printStackTrace();
		}

		getSubscriptionInfo(accessServer);
        if (accessServer.isOpen()) {
        	accessServer.close();
        }

		System.out.println(NEWLINE + "All done");

   }


	 static void readConfigFile(String configfile) {


	        String path = null;
	        File config = new File(configfile);
	        if (!config.exists()) {
	        	try {
					path = config.getCanonicalPath();
				} catch (IOException e) {
					e.printStackTrace();
				}
	        	System.out.println("Config file " + configfile + " does not exist" + path);
	        	System.exit(0);
	        }
	        try {
	          BufferedReader br = new BufferedReader(new FileReader( config));
	          while (true) {
	             String line = br.readLine();
	             if (line == null) break;
	             if (line.trim().startsWith("//")) {
	                 continue;
	             }
	             else if (line.trim().startsWith("/*")) {
	                 while (!line.trim().endsWith("*/")) {
	                     line += br.readLine();
	                 }
	                 continue;
	             }


	             if (line.startsWith("ASUser=")) {
	               user =  line.substring(line.indexOf("ASUser=" )+ 7,line.length()).trim();

	             }
	             else if (line.startsWith("ASPass=")){
	            	  password = line.substring(line.indexOf("ASPass=" )+ 7,line.length()).trim();
	             }
	             else if (line.startsWith("ASHost=")){
	                 host = line.substring(line.indexOf("ASHost=" )+ 7,line.length()).trim();
	             }
	             else if (line.startsWith("ASPort=")){
	                 port = line.substring(line.indexOf("ASPort=" )+ 7,line.length()).trim();
	                 if (port != null) {
	                	 try {
							portnumber = Integer.parseInt(port);
						} catch (NumberFormatException e) {
							System.out.println("Problem parsing the port number from config file:" + port);
							System.exit(0);
						}
	                 }
	             }
	             else {
	            	 System.out.println("Unrecognized key=value:" + line);
	            	 System.exit(0);
	             }
	          }//while
	        }
	        catch(IOException e) {
	            e.printStackTrace();
	            System.exit(0);

	        }
	    }

	/*
	 *Examine subscriptions and report on latency if agents are running
     */

    private static void getSubscriptionInfo(DataSource accessServer) {

    	String replicationMethod = "Refresh";
    	String replicationStatus = "Active";

    	StringBuffer report = new StringBuffer();
    	HashMap<String,Integer> latencyMap = new HashMap<String,Integer>();
    	HashMap<String,ArrayList<String>> tablemappings = new  HashMap<String,ArrayList<String>>();
    	HashMap<String,String> subDescription = new  HashMap<String,String>();
    	HashMap<String,String> pubDescription = new  HashMap<String,String>();
    	HashMap<String,String> pubidMap = new HashMap<String,String>();


	    System.out.println("Get replication activity for all subscriptions for all agents...");

        try {

			if (accessServer != null && accessServer.isOpen()) {

				//first check each subscriber
				//a subscriber is needed to gets list of its publication names.
				//using those, get a Publication object for each from which we
				//can get the source and target table names within this pub.
				//Then get summary statistics and extract the latency from it.
				//If replication is not running, latency will be -1.
				//Later when this is used, null and -1 will be converted to Not mirroring

				Subscriber[] subs = accessServer.getSubscribers();
				//System.out.println("Gathering publication info...");
				for (Subscriber subscriber : subs) {
					//System.out.println("Agent (subscriber):" + s.getName());
					try {
					   subscriber.connect();
					}
					catch (ApiException e) { //skip it if a connection can't be gotten
						if (e.getMessage().startsWith("Unable to connect to datastore" + subscriber.getName())) {
							continue;
						}
						else { //might be some other exception. print it if you need to debug, but otherwise skip it.
							//System.out.println(e.getMessage());
							continue;
						}
					}
					//Create a map with publicationid -> ArrayList of Path.SourceTable,Path.TargetTable mappings for the sub
					String[] pubs = subscriber.getPublicationNames();
					for (String pubname : pubs) {
						Publication publication = subscriber.getPublication(pubname);
						//get sourceTable -> targetTable mappings

						String desc = "";
						Subscriber sub = publication.getSubscriber();
						desc = sub.getDescription();

						subDescription.put(pubname, desc);


						DBPath[] pubPaths = publication.getDBPaths();
						for (DBPath path : pubPaths) {
							ArrayList<String> mappings = new ArrayList<String>();
							PublishedTable[] pubtables = publication.getPublishedTables(path);
							for (PublishedTable pubTable : pubtables) {
								String sourceTable = path.getName() + "." + pubTable.getName();
								TableAssignment assignment = pubTable.getTableAssignment();
								DBTable tgttable = assignment.getDestinedTable();
								String targetTable = tgttable.getFullName();
								mappings.add(sourceTable + "," + targetTable);
							}
							tablemappings.put(pubname, mappings);
						}
						SummaryStatisticData summaryData = new SummaryStatisticData();
						publication.requestSummaryStatistics(summaryData);
						int latencyValue = summaryData.getLatencyValue();

						latencyMap.put(pubname,new Integer(latencyValue));
					}
					subscriber.disconnect();
				}

				//Now get publishers, and from those get Subscription objects.
				//From these statuses can be gotten for the subscription
				//And then for each source table. It's possible to have a
				//subscription mirroring but with one or more of its tables
				//parked, or possibly configured for Refresh. So this sample
				//will show the statuses of each source table
				Publisher[] publishers = accessServer.getPublishers();
				for (Publisher publisher : publishers) {
					String publishername = publisher.getName();
					//System.out.println(NEWLINE + "Agent (publisher): " + publishername);
					report.append(publishername +",");

					String underline = "-------";
					for (int i=0;i<publishername.length();i++) {
						underline += "-";
					}
					//System.out.println(underline);
					if (!publisher.isConnected()) {

						try {
							publisher.connect();
						} catch (ApiException e) {
							//System.out.println("Unable to connect to agent (publisher) " + publisher.getName() + " - may not be running, skipping it");
							continue;
				        }
					}
					String[] subnames = publisher.getSubscriptionNames();
					if (subnames.length==0) {
						System.out.println("No subscriptions configured with this agent as source.");
					}
					for (String sub : subnames)

					{
						report.append(sub + ",");
						Subscription subscription = publisher.getSubscription(sub);
						//sample bug fix
						//get the publisherid (aka syssourceid, aka publishername)
						//By default this is the 1st 8 characters of the subscription name,
						//but can be set to any 8 unique characters at sub creation time by the user
						//if you use short (ie <9 char) subnames then subname=pubname, otherwise they are not the same
						Context subCtx = subscription.getProperty();
						String publisherid = subCtx.getString(Subscription.PublisherID);
						if (publisherid.length()==0){
							publisherid = Subscription.PublisherIDPending;
							subCtx.getString(Subscription.PublisherIDPending);
						}
						else {
							publisherid = subCtx.getString(Subscription.PublisherID);
						}
						pubidMap.put(publisherid, subscription.getName());

						String desc = "";
						Publisher pub = subscription.getPublisher();
						desc = pub.getDescription();

						pubDescription.put(publisherid, desc);

						if (subscription.isLiveStatusSupported()){
							String activity = null;
							String status = null;

							byte[] statuses = subscription.getLiveActivityStatus();
							for (byte b : statuses) {
								/*
								 * (LIVE_ACTIVITY_DESCRIBE, LIVE_ACTIVITY_IDLE, LIVE_ACTIVITY_MIRROR, LIVE_ACTIVITY_NET_CHANGE, or LIVE_ACTIVITY_REFRESH
								 */
								if (Subscription.LIVE_ACTIVITY_DESCRIBE==b) {
									activity = "LIVE_ACTIVTY_DESCRIBE";
								}
								else if (Subscription.LIVE_ACTIVITY_IDLE==b) {
									activity = "LIVE_ACTIVTY_IDLE";
								}
								else if (Subscription.LIVE_ACTIVITY_MIRROR==b) {
									activity = "LIVE_ACTIVTY_MIRROR";
								}
								else if (Subscription.LIVE_ACTIVITY_NET_CHANGE==b) {
									activity = "LIVE_NET_CHANGE";
								}
								else if (Subscription.LIVE_ACTIVITY_REFRESH==b) {
									activity = "LIVE_ACTIVTY_REFRESH";
								}
								else {
									activity = "UNKNOWN";
								}
								/*
								LIVE_STATUS_ACTIVE, LIVE_STATUS_BLOCKED, LIVE_STATUS_IDLE, LIVE_STATUS_RECOVERY, LIVE_STATUS_START,
								LIVE_STATUS_WAIT, LIVE_STATUS_DS_STARTING_JOB, LIVE_STATUS_DS_WAITING_FOR_JOB_TO_START,
								LIVE_STATUS_DS_CONNECTING_WITH_TARGET, or LIVE_STATUS_DS_JOB_ENDING).
								*/
								if (Subscription.LIVE_STATUS_ACTIVE==b) {
									status = "Active";
								}
								else if (Subscription.LIVE_STATUS_BLOCKED==b) {
									status = "Blocked";
								}
								else if (Subscription.LIVE_STATUS_IDLE==b) {
									status = "Idle";
								}
								else if (Subscription.LIVE_STATUS_RECOVERY==b) {
									status= "Net Change";
								}
								else if (Subscription.LIVE_STATUS_START==b) {
									status = "Start";
								}
								else if (Subscription.LIVE_STATUS_WAIT==b) {
									status = "Wait";
								}
								else if (Subscription.LIVE_STATUS_DS_STARTING_JOB==b) {
									status = "DS Starting Job";
								}
								else if (Subscription.LIVE_STATUS_DS_WAITING_FOR_JOB_TO_START==b) {
									status = "DS Wating";
								}
								else if (Subscription.LIVE_STATUS_DS_CONNECTING_WITH_TARGET==b) {
									status = "DS Connecting";
								}
								else if (Subscription.LIVE_STATUS_DS_JOB_ENDING==b) {
									status = "DS Ending Job";
								}
								else {
									status = "UNKNOWN";
								}

							}
							//System.out.println("Subscription: " + sub + " Status: " + status + " Latency: " + latency);
						}

						//Now get the status for each source table mapping
						/* not needed for csv report
						DBPath[] paths = subscription.getSubscribedTableDBPaths();
						for (DBPath path : paths) {
							SubscribedTable[] subscribedtables = subscription.getSubscribedTables(path);
							for (SubscribedTable table : subscribedtables) {
								String name = table.getName();
								if (SubscribedTable.METHOD_MIRROR == table.getReplicationMethod()) {
									replicationMethod = "Mirror";
								}
								else {
									replicationMethod = "Refresh";
								}
								if (SubscribedTable.STATUS_IDLE == table.getReplicationStatus()) {
									replicationStatus = "Parked";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_ACTIVE == table.getReplicationStatus()) {
									replicationStatus = "Active";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_REFRESH == table.getReplicationStatus()) {
									replicationStatus = "Refresh";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_ACTIVE_FULLY == table.getReplicationStatus()) {
									replicationStatus = "Active";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_ACTIVE_IGNORE == table.getReplicationStatus()) {
									replicationStatus = "Active_Ignore";
									System.out.println("here2:" + table.getReplicationStatus());
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_FIX_UP_REFRESH == table.getReplicationStatus()) {
									replicationStatus = "Differential_Refresh";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_FIX_UP_REFRESH_LOG_ONLY == table.getReplicationStatus()) {
									replicationStatus = "Differential_Refresh_LogOnly";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_FIX_UP_REFRESH_WITH_LOG == table.getReplicationStatus()) {
									replicationStatus = "Differential_Refresh_With_Log";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_MEMBER == table.getReplicationStatus()) {
									replicationStatus = "Member";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_NO_MEMBER == table.getReplicationStatus()) {
									replicationStatus = "No_Member";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else {
									System.out.println("Else: " + table.getReplicationStatus());
									continue;
								}
							}//for each subscribed table in sub:path
						}//for each path in subscription
						System.out.println(" ");
						*/
					}//for each subscription in publisher

					if (publisher != null && publisher.isConnected()) {
					    publisher.disconnect();
					}
				}//for each publisher
			}//if
		} catch (ApiException e) {
			e.printStackTrace();
		}

        //Display comma-delimited sub_name, pulicatrionid,,srctable,tgttable,latency
        //latency is per subscription so will be the same value for all mappings in a subscription
        System.out.println("\r\nPUBDESC,SUBDESC,SUBSCRIPTION,PUBID,SRCTBL,TGTTBL,LATENCY");
        System.out.println("--------------------------------------------------------");
        Set<String> subscriptions = tablemappings.keySet();
        Iterator<String> it = subscriptions.iterator();

        while (it.hasNext()) {
        	String pubid = it.next();

        	String subname = pubidMap.get(pubid);
        	String sourceDesc = pubDescription.get(pubid);
        	String targetDesc = subDescription.get(pubid);

        	//if the subname is null, it means the publisher agent is not available or not running, so skip it
        	if (subname==null) {
        		continue;
        	}


        	ArrayList<String> maps  = tablemappings.get(pubid);
        	String latency = "Not mirroring";
			Integer latencyVal = latencyMap.get(pubid);
			if (latencyVal!=null && latencyVal.intValue()>-1 ) {
				  latency = latencyVal.toString();
			}
        	for (int i=0;i<maps.size();i++) {
        	   System.out.println(sourceDesc+","+ targetDesc +","+ subname + "," + pubid + "," + maps.get(i) +"," + latency);
        	}
        }


   }



}

