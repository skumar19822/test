
/****************************************************************************
** Licensed Materials - Property of IBM 
** IBM InfoSphere Change Data Capture
** 5724-U70
** 
** (c) Copyright IBM Corp. 2011 All rights reserved.
** 
** The following sample of source code ("Sample") is owned by International 
** Business Machines Corporation or one of its subsidiaries ("IBM") and is 
** copyrighted and licensed, not sold. You may use, copy, modify, and 
** distribute the Sample in any form without payment to IBM.
** 
** The Sample code is provided to you on an "AS IS" basis, without warranty of 
** any kind. IBM HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
** IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Some jurisdictions do 
** not allow for the exclusion or limitation of implied warranties, so the above 
** limitations or exclusions may not apply to you. IBM shall not be liable for 
** any damages you suffer as a result of using, copying, modifying or 
** distributing the Sample, even if IBM has been advised of the possibility of 
** such damages.
*****************************************************************************/

/**
 * This sample shows how to use the api  to get the staus for all subscriptions
 * and output the results to stdout. 
 
 * All subscriptions in all agents are checked. If an agent is not available 
 * (i.e. not running) then it's reported sand skipped.
 *
 * This is an extension of the GetParkedTables sample which only looked for 
 * and reported parked table mappings. 
 *
 */


package api.sample;

import com.datamirror.ea.api.ApiException;
import com.datamirror.ea.api.DBPath;
import com.datamirror.ea.api.DataSource;
import com.datamirror.ea.api.DefaultContext;
import com.datamirror.ea.api.Toolkit;
import com.datamirror.ea.api.publisher.Publisher;
import com.datamirror.ea.api.publisher.SubscribedTable;
import com.datamirror.ea.api.publisher.Subscription;


public class GetReplicationStatus {
	
	//Access Server credentials
	private static final String USER = "accessServerUser";
	private static final String PASSWORD = "password";
	private static final String HOST = "acessServerHost";
	private static final int PORT = 10101;
	
    private static DataSource accessServer;
    private static final String NEWLINE = System.getProperty("line.separator");
    
	
	public static void main(String[] args) {
	
		DefaultContext c = new DefaultContext();
		c.setString(DataSource.User, USER);
		c.setString(DataSource.Password, PASSWORD);
		c.setString(DataSource.Hostname, HOST);
		c.setInt(DataSource.Port, PORT);
	    
	    try {
			accessServer = Toolkit.getDefaultToolkit().createDataSource();
			accessServer.connect(c);
		} catch (ApiException e) {
			e.printStackTrace();
		}
		
		
		System.out.println("Start");
		getSubscriptionInfo(accessServer);
	   
		System.out.println(NEWLINE + "All done");

   }
	
	/*
	 *Examine subscriptions for parked table mappings and output results to stdout
     */
	
    private static void getSubscriptionInfo(DataSource accessServer) {
	   
    	String replicationMethod = "Refresh";
    	String replicationStatus = "Active";
    	
	    System.out.println("Get replication activity for all subscriptions for all agents...");
	    
        try {
			
			if (accessServer != null && accessServer.isOpen()) {
				Publisher[] publishers = accessServer.getPublishers();
				for (Publisher publisher : publishers) {
					String publishername = publisher.getName();
					System.out.println(NEWLINE + "Agent: " + publishername);
					String underline = "-------";
					for (int i=0;i<publishername.length();i++) {
						underline += "-";
					}
					System.out.println(underline);
					if (!publisher.isConnected()) {
						
						try {
							publisher.connect();
						} catch (ApiException e) {
							System.out.println("Unable to connect to agent " + publisher.getName() + " - may not be running, skipping it");
							continue;
				        }
					} 
					String[] subnames = publisher.getSubscriptionNames();
					if (subnames.length==0) {
						System.out.println("No subscriptions configured with this agent as source.");
					}
					for (String sub : subnames) {
						Subscription subscription = publisher.getSubscription(sub);
						if (subscription.isLiveStatusSupported()){
							String activity = null;
							String status = null;
							
							byte[] statuses = subscription.getLiveActivityStatus();
							for (byte b : statuses) {
								/*
								 * (LIVE_ACTIVITY_DESCRIBE, LIVE_ACTIVITY_IDLE, LIVE_ACTIVITY_MIRROR, LIVE_ACTIVITY_NET_CHANGE, or LIVE_ACTIVITY_REFRESH
								 */
								if (Subscription.LIVE_ACTIVITY_DESCRIBE==b) {
									activity = "LIVE_ACTIVTY_DESCRIBE";
								}
								else if (Subscription.LIVE_ACTIVITY_IDLE==b) {
									activity = "LIVE_ACTIVTY_IDLE";
								}
								else if (Subscription.LIVE_ACTIVITY_MIRROR==b) {
									activity = "LIVE_ACTIVTY_MIRROR";
								}
								else if (Subscription.LIVE_ACTIVITY_NET_CHANGE==b) {
									activity = "LIVE_NET_CHANGE";
								}
								else if (Subscription.LIVE_ACTIVITY_REFRESH==b) {
									activity = "LIVE_ACTIVTY_REFRESH";
								}
								else {
									activity = "UNKNOWN";
								}
								/*
								LIVE_STATUS_ACTIVE, LIVE_STATUS_BLOCKED, LIVE_STATUS_IDLE, LIVE_STATUS_RECOVERY, LIVE_STATUS_START, 
								LIVE_STATUS_WAIT, LIVE_STATUS_DS_STARTING_JOB, LIVE_STATUS_DS_WAITING_FOR_JOB_TO_START, 
								LIVE_STATUS_DS_CONNECTING_WITH_TARGET, or LIVE_STATUS_DS_JOB_ENDING).
								*/
								if (Subscription.LIVE_STATUS_ACTIVE==b) {
									status = "Active";
								}
								else if (Subscription.LIVE_STATUS_BLOCKED==b) {
									status = "Blocked";
								}
								else if (Subscription.LIVE_STATUS_IDLE==b) {
									status = "Idle";
								}
								else if (Subscription.LIVE_STATUS_RECOVERY==b) {
									status= "Net Change";
								}
								else if (Subscription.LIVE_STATUS_START==b) {
									status = "Start";
								}
								else if (Subscription.LIVE_STATUS_WAIT==b) {
									status = "Wait";
								}
								else if (Subscription.LIVE_STATUS_DS_STARTING_JOB==b) {
									status = "DS Starting Job";
								}
								else if (Subscription.LIVE_STATUS_DS_WAITING_FOR_JOB_TO_START==b) {
									status = "DS Wating";
								}
								else if (Subscription.LIVE_STATUS_DS_CONNECTING_WITH_TARGET==b) {
									status = "DS Connecting";
								}
								else if (Subscription.LIVE_STATUS_DS_JOB_ENDING==b) {
									status = "DS Ending Job";
								}
								else {
									status = "UNKNOWN";
								}
								
							}
							System.out.println("Subscription: " + sub + " Status: " + status);
						}
						DBPath[] paths = subscription.getSubscribedTableDBPaths();
						for (DBPath path : paths) {
							SubscribedTable[] subscribedtables = subscription.getSubscribedTables(path);
							for (SubscribedTable table : subscribedtables) {
								String name = table.getName();
								if (SubscribedTable.METHOD_MIRROR == table.getReplicationMethod()) {
									replicationMethod = "Mirror";
								}
								else {
									replicationMethod = "Refresh";
								}
								if (SubscribedTable.STATUS_IDLE == table.getReplicationStatus()) {
									replicationStatus = "Parked";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_ACTIVE == table.getReplicationStatus()) {
									replicationStatus = "Active";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_REFRESH == table.getReplicationStatus()) {
									replicationStatus = "Refresh";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_ACTIVE_FULLY == table.getReplicationStatus()) {
									replicationStatus = "Active";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_ACTIVE_IGNORE == table.getReplicationStatus()) {
									replicationStatus = "Active_Ignore";
									System.out.println("here2:" + table.getReplicationStatus());
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_FIX_UP_REFRESH == table.getReplicationStatus()) {
									replicationStatus = "Differential_Refresh";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_FIX_UP_REFRESH_LOG_ONLY == table.getReplicationStatus()) {
									replicationStatus = "Differential_Refresh_LogOnly";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_FIX_UP_REFRESH_WITH_LOG == table.getReplicationStatus()) {
									replicationStatus = "Differential_Refresh_With_Log";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_MEMBER == table.getReplicationStatus()) {
									replicationStatus = "Member";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else if (SubscribedTable.STATUS_NO_MEMBER == table.getReplicationStatus()) {
									replicationStatus = "No_Member";
									System.out.println("Source Table: " + path.getName() + "." + name + " Status:\t" + replicationMethod + "/" + replicationStatus);
								}
								else {
									System.out.println("Else: " + table.getReplicationStatus());
									//SubscribedTable.s
									continue;
								}
							}//for each subscribed table in sub:path
						}//for each path in subscription
						System.out.println(" ");
					}//for each subscription in publisher
					
					if (publisher != null && publisher.isConnected()) {
					    publisher.disconnect();
					}
					
				}//for each publisher
			}//if
		} catch (ApiException e) {
			e.printStackTrace();
		}

	   
	   
   }
   


}

