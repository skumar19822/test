Sample User Exit (AlertFileHandler.java)

How to monitor CDC logs for Tivoli or other monitoring tools
============================================================
Use the CDC notifications user exit (Java) and have this populate a file that is monitored by Tivoli (or other tool).
You can set up CDC notifications at the datastore level and then every subscription will use this. This user exit reads a property file, so it's possible to control file name and also it's max size. If the file size is bigger than specified, it will be renamed and a new file will be opened.