/****************************************************************************
** Licensed Materials - Property of IBM 
** IBM InfoSphere Change Data Capture
** 5724-U70
** 
** (c) Copyright IBM Corp. 2011 All rights reserved.
** 
** The following sample of source code ("Sample") is owned by International 
** Business Machines Corporation or one of its subsidiaries ("IBM") and is 
** copyrighted and licensed, not sold. You may use, copy, modify, and 
** distribute the Sample in any form without payment to IBM.
** 
** The Sample code is provided to you on an "AS IS" basis, without warranty of 
** any kind. IBM HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
** IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Some jurisdictions do 
** not allow for the exclusion or limitation of implied warranties, so the above 
** limitations or exclusions may not apply to you. IBM shall not be liable for 
** any damages you suffer as a result of using, copying, modifying or 
** distributing the Sample, even if IBM has been advised of the possibility of 
** such damages.
*****************************************************************************/

import com.datamirror.ts.api.*;
import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;

/**
 *
 * AlertFileHandler is an implementation of the AlertHandlerIF.
 */
public class AlertFileHandler implements AlertHandlerIF
{
   public Properties properties;
    
   /**
    * User exit <b>must have</b> constructor with no arguments.
    * Though it would exist by default, it is adduced here for clearness.
    */
   public AlertFileHandler()
   {
	   this.properties = new Properties(); 
	   
	   try { 
		   properties.load(new FileInputStream("alertfile.properties")); 
	   } 
	   catch (IOException e) 
	   { 
		   properties.setProperty("file", "cdc.log");
		   properties.setProperty("size", "100");
	   } 
   }

   
   public void handle(int p_zoneID,
            int p_categoryID,
            String p_SourceOrTarget,
            String p_Name,
            int p_EventID,
            String p_EventText,
            Properties p_OtherInfo)
            throws Exception
   {
   try {
	   
	  String logFileName = properties.getProperty("file", "cdc.log"); 
	  Long size = new Long(properties.getProperty("size", "100"));
	  
      FileOutputStream fos = new FileOutputStream(logFileName, true);
      
      OutputStreamWriter osw = new OutputStreamWriter(fos);
      BufferedWriter bw = new BufferedWriter(osw);
      /*Time*/
      Calendar Cal    = new GregorianCalendar(new Locale("en","US"));
      Cal.setTime(new Date());
      SimpleDateFormat DF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

      String[] zones = { "", "Scrape/Refresh","Communication","Environment","Journal","Communication","Apply","Environment"  };
	  String[] categories = { "", "Fatal","Error","Information","Status","Operational" };
      
	  int tmpZoneID = p_zoneID;
	  if (p_SourceOrTarget.equals("T")) {
		  tmpZoneID += 4; 
	  }
	  
      String msg = DF.format(Cal.getTime())+".|"+p_SourceOrTarget+"|"+p_Name+"|"+p_EventID+"|"+categories[p_categoryID]+"|"+zones[tmpZoneID]+"|"+p_EventText+"\n";
      bw.write(msg);
      
      bw.close();
      osw.close();
      fos.close();
      
      SimpleDateFormat DF2 = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
      
      File file = new File(logFileName); 
      File newFile = new File(logFileName+"_"+DF2.format(new Date()));
      
      if (file.length() > size.longValue()*1024)
      {
    	  file.renameTo(newFile);
      }
      
    } catch (Exception e) {
      e.printStackTrace();
    }
      return ;
   }
}