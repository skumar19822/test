/****************************************************************************
** Licensed Materials - Property of IBM 
** IBM InfoSphere Change Data Capture
** 5724-U70
** 
** (c) Copyright IBM Corp. 2012 All rights reserved.
** 
** The following sample of source code ("Sample") is owned by International 
** Business Machines Corporation or one of its subsidiaries ("IBM") and is 
** copyrighted and licensed, not sold. You may use, copy, modify, and 
** distribute the Sample in any form without payment to IBM.
** 
** The Sample code is provided to you on an "AS IS" basis, without warranty of 
** any kind. IBM HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
** IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Some jurisdictions do 
** not allow for the exclusion or limitation of implied warranties, so the above 
** limitations or exclusions may not apply to you. IBM shall not be liable for 
** any damages you suffer as a result of using, copying, modifying or 
** distributing the Sample, even if IBM has been advised of the possibility of 
** such damages.
*****************************************************************************/
#Check if the parameters are appropiate
if [ $# -ne 1 ]; then
 echo ---------------------------------------
 echo 1>&2 Usage: $0 "start|stop|status"
 echo ---------------------------------------
 exit 127
fi

#!/bin/bash
# set -x

# CDC instance variables
CDC_HOME=/opt/IBM/InfoSphereChangeDataCapture/ReplicationEngineforIBMInfoSphereDataStage
CDC_USER=cdcadmin
CDC_INSTANCE=`ls ${CDC_HOME}/instance | head -1`

# First start database
#`dirname $0`/Database_DB2_start.sh nowait

Istart()
{
	Istatus
        if [ $STATUS == 0 ]; then

		# Start CDC instance
		echo "- Starting CDC instance ${CDC_INSTANCE} for user ${CDC_USER} ..."
		rm ${CDC_HOME}/bin/nohup.out 2> /dev/null
		#${CDC_HOME}/bin;nohup ./dmts32 -I ${CDC_INSTANCE} &" > ${CDC_HOME}/bin/nohup.out
	        eval "nohup  ${CDC_HOME}/bin/dmts64 -I ${CDC_INSTANCE} > ${CDC_HOME}/bin/nohup.out &"

		# Wait for CDC instance to be started or error to be issued (max 60 seconds)
		for i in {1..60} 
		  do
		    if [ -e ${CDC_HOME}/bin/nohup.out ];
		      then
			nLines=$(wc -l ${CDC_HOME}/bin/nohup.out | awk '{print $1}')
			if (( ${nLines} != 0 ))
			  then
			    break
			  fi
		      fi
		      echo -en "\r$(echo - Attempting ${i}/60)"
		      sleep 1
		  done
		echo
		# Determine if instance was started correctly
		nLines=$(grep -c "IBM InfoSphere Change Data Capture is running." ${CDC_HOME}/bin/nohup.out)

		if (( ${nLines} != 0 ))
		  then  
		    # Do post-instance action such as clearing the staging store or setting system parameters
		    echo post-start > /dev/null
		fi

		echo "- Checking if Instance '${CDC_INSTANCE}' has been started properly..."
		Istatus
		if [ $STATUS == 0 ]; then
        		RESULT=1
		else
		        RESULT=0
		fi
	fi
}

Istop()
{
	Istatus
	if [ $STATUS == 1 ]; then
		# Stop CDC instance
		echo "- Stopping CDC instance ${CDC_INSTANCE} ..."
		${CDC_HOME}/bin/dmshutdown -I ${CDC_INSTANCE} > /dev/null
		sleep 1
	 	echo "- Checking if Instance '${CDC_INSTANCE}' has been stopped properly..."
		Istatus
		if [ $STATUS == 1 ]; then
        		RESULT=1
		else
        		RESULT=0
		fi
	fi
}

Istatus(){
	#Checking CDC instance status
	if (ps -u ${CDC_USER} | grep -v grep | grep -i "dmts") > /dev/null
	then
	   echo "- CDC Instance '${CDC_INSTANCE}' is active"
           STATUS=1
	else
           echo "- CDC Instance '${CDC_INSTANCE}' is not active"
	   STATUS=0
	fi
}

echo ---------------------------------------
if [[ "$1" == "start" ]] ; then
 Istart
fi

if [[ "$1" == "stop" ]] ; then
 Istop
fi

if [[ "$1" == "status" ]] ; then
 Istatus
 RESULT=0
fi

if [[ "$1" != "start" && "$1" != "stop" && "$1" != "status" ]] ; then
 echo "Usage: $0 [start|stop|status]..."
fi

echo ---------------------------------------
exit $RESULT

