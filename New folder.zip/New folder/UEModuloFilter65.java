import java.math.BigDecimal;

import com.datamirror.ts.derivedexpressionmanager.DEUserExitIF;
import com.datamirror.ts.derivedexpressionmanager.UserExitInvalidArgumentException;
import com.datamirror.ts.derivedexpressionmanager.UserExitInvokeException;
import com.datamirror.ts.util.Trace;

/* 
Overview:
	The user exit will perform a modulo operation against a specified column and determine if it equals
	the specified remainder value.  The parameters passed into the user exit are:
		a) Column Name -> this must be the name of a source numeric column  (IT MUST BE NUMERIC!)
		b) Modulo Number -> this is the modulo number
		c) Remainder Value -> remainder value

	The logic is as follows:

		<value of Column> % <Modulo Number> == <remainder value>

Instructions:

	1) Copy the FilteringUserExit.class to the <cdc install>/lib directory
	2) Go to the mapping details for the table 
	3) Under Filtering, specify the following
	
	%USERFUNC("JAVA", "UEModuloFilter65",<column to perform the modulus against>, <the modulo number>, <remainder>)
	
	Return value is boolean, true or false.
*/

public class UEModuloFilter65 implements DEUserExitIF 
{

	   int counter = 1;
	   Boolean retVal = false;

   public Object invoke(Object[] aobjList) throws UserExitInvalidArgumentException, UserExitInvokeException {
	      try {
	    	  long value = ((BigDecimal) aobjList[0]).longValue();
	    	  long modulo = ((BigDecimal) aobjList[1]).longValue();
	    	  long remainder = ((BigDecimal) aobjList[2]).longValue();
	    	  
	    	  return new Boolean ((value % modulo) == remainder );
	      }
	      catch (ClassCastException exc) {
	         Trace.traceAlways(exc);
	         throw new UserExitInvalidArgumentException("Invalid number parameter passed " +
	         		"to the user function: aobjList[0]="+aobjList[0]+",aobjList[1]="+aobjList[1]+
	         		",aobjList[2]="+aobjList[2]+"Message: "+exc.getMessage());
	      }	   
   }
}
