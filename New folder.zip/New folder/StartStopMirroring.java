
/****************************************************************************
** Licensed Materials - Property of IBM
** IBM InfoSphere Change Data Capture
** 5724-U70
**
** (c) Copyright IBM Corp. 2011 All rights reserved.
**
** The following sample of source code ("Sample") is owned by International
** Business Machines Corporation or one of its subsidiaries ("IBM") and is
** copyrighted and licensed, not sold. You may use, copy, modify, and
** distribute the Sample in any form without payment to IBM.
**
** The Sample code is provided to you on an "AS IS" basis, without warranty of
** any kind. IBM HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR
** IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Some jurisdictions do
** not allow for the exclusion or limitation of implied warranties, so the above
** limitations or exclusions may not apply to you. IBM shall not be liable for
** any damages you suffer as a result of using, copying, modifying or
** distributing the Sample, even if IBM has been advised of the possibility of
** such damages.
*****************************************************************************/

/**
 * This sample shows how to use the API to start a subscription in mirror
 * continuous.
 *
 * It requires Management Console api.jar to compile and run.
 *
 * For details of the API, open <Management Console install dir>/api/index.html
 * in your browser. Most MC functionality has a counterpart in the API to allow
 * you to automate MC tasks programmatically.
 * 
 * This sample can start mirroring continuous, and can end mirroring in normal 
 * (controlled), immediate and abort. (If abort is used and the version is 6.3
 * immediate will be used.
 * 
 * Note there are other modes of starting replication that can be easily added, 
 * as well other modes of ending (eg scheduled end.)
 *
 * 
 */


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import com.datamirror.ea.api.ApiException;
import com.datamirror.ea.api.DataSource;
import com.datamirror.ea.api.DefaultContext;
import com.datamirror.ea.api.Toolkit;
import com.datamirror.ea.api.UnsupportedFeatureException;
import com.datamirror.ea.api.publisher.Publisher;
import com.datamirror.ea.api.publisher.Subscription;


public class StartStopMirroring {

	//For Access Server credentials
	private static String user 	= "";
	private static String password = "";
	private static String host = "";
	private static String port = "";
	private static int portnumber = 10101;
	
	private static final String NEWLINE = System.getProperty("line.separator");
	
    private static final String USAGE = "Provide the name and location of " +
    	"AccessServer.cfg, the publisher agent name, and the subscription " +
    	"name as arguments, the action [start | end] and the type of stop " +
		"[normal (controlled) | immediate | abort]" + NEWLINE +
		"Example: java StartStopMirroring /CDC/AccessServer.cfg PUB1 SUB1 " +
		" end normal";
    
    private static final String CFGFILE = "ASUser=Pete" + NEWLINE +
    									  "ASPass=Temp" + NEWLINE +
    									  "ASHost=localhost" + NEWLINE +
    									  "ASPort=10101";
    

    private static DataSource accessServer;

    private static String access_server_configfile="";
    private static String subscriptionName = "";
    private static String publisherAgentName = "";
    private static String action = "";
    private static String endType = "";
    private static final boolean CONTINUOUS = true;

	public static void main(String[] args) {

        //only valid arg is location of user defined properties file
        if  (args.length<4) {
        	
           	System.out.println("Usage:" +USAGE);
        	System.out.println("AccessServer.cfg must be in the following format:");
        	System.out.println(CFGFILE);
            System.exit(0);
        }
        
        access_server_configfile = args[0];
        publisherAgentName = args[1];
        subscriptionName = args[2];
        action = args[3];
        if (action.equalsIgnoreCase("end")) {
        	if (args.length==4) {//default to normal if type not supplied
        		endType="normal";
        	}
        	else if (args.length==5) {
        		endType = args[4];
        	}
        }

        readConfigFile(access_server_configfile);

        System.out.println("Connecting to AccessServer at " + host + " on " +
        							"port:" + port + " as UserID " + user);

		DefaultContext c = new DefaultContext();
		c.setString(DataSource.User, user);
		c.setString(DataSource.Password, password);
		c.setString(DataSource.Hostname, host);
		c.setInt(DataSource.Port, portnumber);

	    try {
			accessServer = Toolkit.getDefaultToolkit().createDataSource();
			accessServer.connect(c);
		} catch (ApiException e) {
			e.printStackTrace();
		}
        if (action.equalsIgnoreCase("start")) {
        	startSubMirroring(accessServer,publisherAgentName, subscriptionName);
        	System.out.println("Mirroring started for subscription " + subscriptionName );
        }
        else if (action.equalsIgnoreCase("end")) {
        	endMirroring(accessServer,publisherAgentName, subscriptionName,endType);
        	System.out.println("Mirroring ended for subscription " + subscriptionName );
        }
        else {
        	System.out.println("Unrecognized action given: " + action );
        	System.out.println("Only start and end are allowed.");
        	System.exit(0);
        }
        

        if (accessServer.isOpen()) {
        	accessServer.close();
        }

		

   }


	 static void readConfigFile(String configfile) {


	        String path = null;
	        File config = new File(configfile);
	        if (!config.exists()) {
	        	try {
					path = config.getCanonicalPath();
				} catch (IOException e) {
					e.printStackTrace();
				}
	        	System.out.println("Config file " + configfile + " does not exist" + path);
	        	System.exit(0);
	        }
	        try {
	          BufferedReader br = new BufferedReader(new FileReader( config));
	          while (true) {
	             String line = br.readLine();
	             if (line == null) break;
	             if (line.trim().startsWith("//")) {
	                 continue;
	             }
	             else if (line.trim().startsWith("/*")) {
	                 while (!line.trim().endsWith("*/")) {
	                     line += br.readLine();
	                 }
	                 continue;
	             }


	             if (line.startsWith("ASUser=")) {
	               user =  line.substring(line.indexOf("ASUser=" )+ 7,line.length()).trim();

	             }
	             else if (line.startsWith("ASPass=")){
	            	  password = line.substring(line.indexOf("ASPass=" )+ 7,line.length()).trim();
	             }
	             else if (line.startsWith("ASHost=")){
	                 host = line.substring(line.indexOf("ASHost=" )+ 7,line.length()).trim();
	             }
	             else if (line.startsWith("ASPort=")){
	                 port = line.substring(line.indexOf("ASPort=" )+ 7,line.length()).trim();
	                 if (port != null) {
	                	 try {
							portnumber = Integer.parseInt(port);
						} catch (NumberFormatException e) {
							System.out.println("Problem parsing the port number from config file:" + port);
							System.exit(0);
						}
	                 }
	             }
	             else {
	            	 System.out.println("Unrecognized key=value:" + line);
	            	 System.exit(0);
	             }
	          }//while
	        }
	        catch(IOException e) {
	            e.printStackTrace();
	            System.exit(0);

	        }
	    }

	/*
	 *Start subscription mirroring
     */

    private static void startSubMirroring(DataSource accessServer, String publishername, String subname) {




	    System.out.println("Starting subscription " + subname + " in mirror continuous...");

        try {

			if (accessServer != null && accessServer.isOpen()) {
				Publisher publisher = accessServer.getPublisher(publishername);
				if (publisher==null) {
					System.out.println("Could not access publisher " + publishername);
					System.exit(0);
				}
				try {
					publisher.connect();
				} catch (ApiException e) {
					System.out.println("Unable to connect to agent (publisher) " + publishername + " - may not be running.");

		        }

			    Subscription subscription = publisher.getSubscription(subname);
			    if (subscription==null) {
			    	System.exit(0);
			    }
			    subscription.startMirror(CONTINUOUS);

				if (publisher != null && publisher.isConnected()) {
					    publisher.disconnect();
				}

			}
		} catch (ApiException e) {
			e.printStackTrace();
		}
    }
    
    private static void endMirroring(DataSource accessServer, String publishername, String subname, String endtype) {
    	System.out.println("Stopping subscription " + subname + " with end " + endtype );
    	
    	
    	if (accessServer != null && accessServer.isOpen()) {
			Publisher publisher = accessServer.getPublisher(publishername);
			if (publisher==null) {
				System.out.println("Could not access publisher " + publishername);
				System.exit(0);
			}
			try {
				publisher.connect();
			} catch (ApiException e) {
				System.out.println("Unable to connect to agent (publisher) " + publishername + " - may not be running.");
				System.exit(0);

	        }
		    try {
				Subscription subscription = publisher.getSubscription(subname);
				if (subscription==null) {
					System.exit(0);
				}
								
				//If 6.5 or later, this is the preferred method.
				byte tagval = 0;
				if (endtype.equalsIgnoreCase("normal") || endtype.equalsIgnoreCase("controlled")) {
					tagval = new Integer(6).byteValue();
				}
				else if (endtype.equalsIgnoreCase("immediate")) {
					tagval = new Integer(7).byteValue();
				}
				else if (endtype.equalsIgnoreCase("abort")) {
					tagval = new Integer(8).byteValue();
				}
				else {
					System.out.println("Unrecognized type supplied for replication end");
					System.out.println("Only normal (or controlled) immediate or abort allowed");
					System.exit(0);
				}
				
				//make sure the subscription is actively mirroring before trying to stop it
				byte[] live_status;
				
					if (subscription.isLiveStatusSupported()) {
						 live_status = subscription.getLiveActivityStatus();
						 if (live_status[0]==Subscription.LIVE_ACTIVITY_MIRROR && live_status[1]==Subscription.LIVE_STATUS_ACTIVE) {
							 /*
						     * Parameters:
								flag - 1 - refresh, 2 - mirror, 3 - net change mirror, 4 - mirror to commit boundary, 5 - scheduled end
								tag - 5 - scheduled end, 6 - normal, 7 - immediate, 8 - abort
								endValueType - specifies the type of end value supplied: 1 - log position, 2 - source local time, 4 - now. Only applies when flag is 5 (scheduled end).
								endValue - string representing the end value corresponding to endValueType. Only applies when flag is 5 (scheduled end). When endValueType is 1, supply a log position for endValue. The format of endValue when endValueType is 2 for local source time is "yyyyMMddHHmmssSSS". The agent will interpret the string as the exact date and time in its own time zone. When endValueType is 4, endValue should be empty string.
						     */
							 subscription.endReplicationSpecifiable(new Integer(2).byteValue(),tagval,new Integer(0).byteValue(),"");
						 }
						 else {
							 System.out.println("Cannot end mirroring for subscription " + subname + " because it was not actively mirroring.");
							 System.exit(0);
						 }
					}
					else {
						//6.3 or 6.5 or if getLiveStatus is not supported in this agent (probably 6.3)
						System.out.println("getLiveActivityStatus is not supported.");
						//only choices are stop immediate or normal/controlled with the stopMirror method
						if ( endtype.equalsIgnoreCase("immediate")) {
						    subscription.stopMirror(true);//immediate
						}
						else {
							subscription.stopMirror(false);//controlled 
						}
					}
			} catch (UnsupportedFeatureException e) {
				e.printStackTrace();
			} catch (ApiException e) {
				e.printStackTrace();
			}
			

		    
    	}
    	
    	
    }




}

