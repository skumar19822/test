/****************************************************************************
** Licensed Materials - Property of IBM 
** IBM InfoSphere Change Data Capture
** 5724-U70
** 
** (c) Copyright IBM Corp. 2012 All rights reserved.
** 
** The following sample of source code ("Sample") is owned by International 
** Business Machines Corporation or one of its subsidiaries ("IBM") and is 
** copyrighted and licensed, not sold. You may use, copy, modify, and 
** distribute the Sample in any form without payment to IBM.
** 
** The Sample code is provided to you on an "AS IS" basis, without warranty of 
** any kind. IBM HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER EXPRESS OR 
** IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Some jurisdictions do 
** not allow for the exclusion or limitation of implied warranties, so the above 
** limitations or exclusions may not apply to you. IBM shall not be liable for 
** any damages you suffer as a result of using, copying, modifying or 
** distributing the Sample, even if IBM has been advised of the possibility of 
** such damages.
*****************************************************************************/
#Check if the parameters are apropiate
if [ $# -ne 1 ]; then
 echo ---------------------------------------
 echo 1>&2 Usage: $0 "start|stop|status"
 echo ---------------------------------------
 exit 127
fi

#!/bin/bash --
# set -x

# CDC instance variables
CDC_HOME=/opt/IBM/"InfoSphere\\ Change\\ Data\\ Capture"/"Access\\ Server"
CDC_USER=cdcadmin

echo ---------------------------------------

ASstart()
{
	# Start CDC Access Server
	echo "- Starting CDC Access Server ..."
	#rm ${CDC_HOME}/bin/nohup.out 2> /dev/null
	#eval cd ${CDC_HOME}/bin
	eval "nohup  ${CDC_HOME}/bin/dmaccessserver > dmaccessserver.out &"
#> ${CDC_HOME}/bin/nohup.out
}

ASstop()
{
	#Stopping Access Server:


	echo "- Stopping CDC Access Server ..."
	ps -ef | sed -n '/dmaccessserver/{/grep/!p;}' | awk '{print$2}' | xargs -i kill {}
}

ASstatus()
{
	#Checking Access Server status:
	if (ps -u ${CDC_USER} | grep -v grep | grep -i "dmaccessserver") > /dev/null
	then
	   echo "- CDC Access Server is active"
	   STATUS=1
	else
	   echo "- CDC Access Server is not active"
	   STATUS=0
	fi
}


if [[ "$1" == "start" ]] ; then
 ASstart
 echo "- Checking if Access Server has been stopped properly..."
 sleep 1
 ASstatus
 if [ $STATUS == 0 ]; then
   	RESULT=1
 else
  	RESULT=0
 fi

fi

if [[ "$1" == "stop" ]] ; then
 ASstop
 echo "- Checking if Access Server has been stopped properly..."
 sleep 1
 ASstatus
 if [ $STATUS == 1 ]; then
    	RESULT=1
 else
   	RESULT=0
 fi
fi

if [[ "$1" == "status" ]] ; then
 ASstatus
 RESULT=0
fi

if [[ "$1" != "start" && "$1" != "stop" && "$1" != "status" ]] ; then
 echo "Usage: $0 [start|stop|status]"
fi

echo ---------------------------------------
exit $RESULT
